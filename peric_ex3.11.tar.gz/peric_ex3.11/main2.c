#include <stdint.h>
#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <string.h>
#include <time.h>
#include <limits.h>
#include <fstream>

#define MIN(X,Y) ((X) < (Y) ? (X) : (Y))
#define MAX(X,Y) ((X) > (Y) ? (X) : (Y))
#define ma2d(I) ((I))

typedef struct _State State;
struct _State {
  double lx; // size of domain
  int nx; // number of points on Cartesian grid
  double *x;
  double *y;
  double *dx;
  double *fi;
  };
  State state1, *state ;

using namespace std;

int main(int argc, char *argv[]) {
state=&state1;
state->lx=1.0;
state->nx=10;
int i;

state->x=(double*) malloc(sizeof(double)*(state->nx+1));
state->dx=(double*) malloc(sizeof(double)*(state->nx));
state->fi=(double*) malloc(sizeof(double)*(state->nx+1));


double u[state->nx+1];
double mx[state->nx+1];

for (i=0;i<=state->nx-1;i++)
	{
	state->dx[i]=state->lx/state->nx;
	}
state->x[0]=0.0;
for (i=1;i <= state->nx;i++)
	{
	state->x[i]=state->x[i-1]+state->dx[i-1];
	}

for (i=0;i<=state->nx;i++)
	{
	printf("x  %d =  %12.8f \n  ",i, state->x[i]);
	}	
	
	
double tau=0.02;
double rho=1.0;
for (i=0;i<=state->nx;i++)	
	{
	u[i]=1.0;
	mx[i]=rho*u[i];
	printf("mx %d    = %12.6f \n ",i, mx[i]);
	}
		
double AWC[(state->nx+1)];
double AEC[(state->nx+1)];
double APC[(state->nx+1)];
for (i=0;i<=state->nx;i++)
	{
		AEC[ma2d(i+1)]=0;
		AWC[ma2d(i-1)]=0;
		APC[ma2d(i)]=0;
	}
	


for (i=1;i<=state->nx-1;i++)
	{
		AEC[ma2d(i+1)]=MIN(mx[i],0)/(state->x[i+1]-state->x[i]);
		AWC[ma2d(i-1)]=-MAX(mx[i-1],0)/(state->x[i]-state->x[i-1]);
		APC[ma2d(i)]=-(AEC[ma2d(i+1)]+AWC[ma2d(i-1)]);
	}
	
double AWD[(state->nx+1)];
double AED[(state->nx+1)];
double APD[(state->nx+1)];
for (i=0;i<=state->nx;i++)
	{
		AED[ma2d(i+1)]=0;
		AWD[ma2d(i-1)]=0;
		APD[ma2d(i)]=0;
	}
	


for (i=1;i<=state->nx-1;i++)
	{
		AED[ma2d(i+1)]=-2*tau/((state->x[i+1]-state->x[i-1])*(state->x[i+1]-state->x[i]));
		AWD[ma2d(i-1)]=-2*tau/((state->x[i+1]-state->x[i-1])*(state->x[i]-state->x[i-1]));
		APD[ma2d(i)]=-(AED[ma2d(i+1)]+AWD[ma2d(i-1)]);
	}	
	
double AW[(state->nx+1)];
double AE[(state->nx+1)];
double AP[(state->nx+1)];	
for (i=0;i<=state->nx;i++)
	{
		AE[ma2d(i+1)]=AED[ma2d(i+1)]+AEC[ma2d(i+1)];
		AW[ma2d(i-1)]=AWD[ma2d(i-1)]+AWC[ma2d(i-1)];
		AP[ma2d(i)]=APD[ma2d(i)]+APC[ma2d(i)];
	}
	
	for (i=1;i<=state->nx-1;i++)
	
	{
	state->fi[ma2d(i)]=0.0;
	state->fi[0]=0.0;
	state->fi[state->nx]=1.0;
	}
			
	
double Qp[(state->nx+1)];
for (i=0;i<=state->nx;i++)
	{
	Qp[ma2d(i)]=0.0;
	}
	
	/**********************bc**************************/
	
	 ////WEST BOUNDARY - DIRICHLET B.C. 
      
      
      Qp[ma2d(1)]=Qp[ma2d(1)]-AW[ma2d(0)]*state->fi[ma2d(0)];
      printf("Qp %d   =  %12.8f  \n  ",1, Qp[ma2d(1)]);
      AW[ma2d(0)]=0;
      
             
     
     ///EAST BOUNDARY - OTFLOW B.C. (ZERO-GRAD. EXTRAPOLATION)
      
     //  AP[ma2d(state->nx-1)]=AP[ma2d(state->nx-1)]+AE[ma2d(state->nx)];
     //  printf("AP %d %d  =  %12.8f  \n  ",state->nx,j,AP[ma2d(state->nx)]);
       Qp[ma2d(state->nx-1)]=Qp[ma2d(state->nx-1)]-AE[ma2d(state->nx)]*state->fi[ma2d(state->nx)];
       AE[ma2d(state->nx)]=0;
       
       
       for (int k=1;k<=5000;k++)
{
printf("ITERATION  =  %d  \n ",k);

for (i=1;i<=state->nx-1;i++)

	{
 	state->fi[ma2d(i)]=(-1.0/(AP[ma2d(i)]))*(state->fi[ma2d(i-1)]*AW[ma2d(i-1)]+state->fi[ma2d(i+1)]*AE[ma2d(i+1)]-Qp[ma2d(i)]);
 	printf("fi %d  =  %12.8f \n ",i, state->fi[ma2d(i)] );
	}  
}
       
       ofstream out1;
 out1.open("fi_1d.txt"); 

 for (i=0;i<=state->nx;i++)
  {
 out1<< state->x[i] <<  "  " << state->fi[ma2d(i)]<< endl;
  }
  
  
       
      return 0;  
       
       
       
      }         
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	

